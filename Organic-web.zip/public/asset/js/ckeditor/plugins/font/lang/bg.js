/*
Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
CKEditor 4 LTS ("Long Term Support") is available under the terms of the Extended Support Model.
*/
CKEDITOR.plugins.setLang( 'font', 'bg', {
	fontSize: {
		label: 'Размер',
		voiceLabel: 'Размер на шрифт',
		panelTitle: 'Размер на шрифт'
	},
	label: 'Шрифт',
	panelTitle: 'Име на шрифт',
	voiceLabel: 'Шрифт'
} );
