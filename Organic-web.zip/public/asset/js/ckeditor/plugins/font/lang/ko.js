/*
Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
CKEditor 4 LTS ("Long Term Support") is available under the terms of the Extended Support Model.
*/
CKEDITOR.plugins.setLang( 'font', 'ko', {
	fontSize: {
		label: '크기',
		voiceLabel: '글자 크기',
		panelTitle: '글자 크기'
	},
	label: '글꼴',
	panelTitle: '글꼴',
	voiceLabel: '글꼴'
} );
