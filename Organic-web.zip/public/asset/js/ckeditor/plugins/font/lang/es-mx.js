/*
Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
CKEditor 4 LTS ("Long Term Support") is available under the terms of the Extended Support Model.
*/
CKEDITOR.plugins.setLang( 'font', 'es-mx', {
	fontSize: {
		label: 'Tamaño',
		voiceLabel: 'Tamaño de letra',
		panelTitle: 'Tamaño de letra'
	},
	label: 'Letra',
	panelTitle: 'Nombre de letra',
	voiceLabel: 'Letra'
} );
