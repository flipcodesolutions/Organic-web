/*
Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
CKEditor 4 LTS ("Long Term Support") is available under the terms of the Extended Support Model.
*/
CKEDITOR.plugins.setLang( 'font', 'sr-latn', {
	fontSize: {
		label: 'Veličina ',
		voiceLabel: 'Veličina slova',
		panelTitle: 'Veličina slova'
	},
	label: 'Font',
	panelTitle: 'Naziv fonta',
	voiceLabel: 'Font'
} );
