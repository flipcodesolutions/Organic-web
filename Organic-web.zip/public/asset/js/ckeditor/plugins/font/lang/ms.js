/*
Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
CKEditor 4 LTS ("Long Term Support") is available under the terms of the Extended Support Model.
*/
CKEDITOR.plugins.setLang( 'font', 'ms', {
	fontSize: {
		label: 'Saiz',
		voiceLabel: 'Font Size',
		panelTitle: 'Saiz'
	},
	label: 'Font',
	panelTitle: 'Font',
	voiceLabel: 'Font'
} );
