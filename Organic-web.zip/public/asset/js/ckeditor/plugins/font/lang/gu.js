/*
Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
CKEditor 4 LTS ("Long Term Support") is available under the terms of the Extended Support Model.
*/
CKEDITOR.plugins.setLang( 'font', 'gu', {
	fontSize: {
		label: 'ફૉન્ટ સાઇઝ/કદ',
		voiceLabel: 'ફોન્ટ સાઈઝ',
		panelTitle: 'ફૉન્ટ સાઇઝ/કદ'
	},
	label: 'ફૉન્ટ',
	panelTitle: 'ફૉન્ટ',
	voiceLabel: 'ફોન્ટ'
} );
