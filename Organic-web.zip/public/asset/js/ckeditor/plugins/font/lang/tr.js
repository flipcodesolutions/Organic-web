/*
Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
CKEditor 4 LTS ("Long Term Support") is available under the terms of the Extended Support Model.
*/
CKEDITOR.plugins.setLang( 'font', 'tr', {
	fontSize: {
		label: 'Boyut',
		voiceLabel: 'Font Size',
		panelTitle: 'Boyut'
	},
	label: 'Yazı Türü',
	panelTitle: 'Yazı Türü',
	voiceLabel: 'Font'
} );
